﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excepciones
{
    public class DniInvalidoException:Exception
    {
        #region Fields
        private string mensaje;
        #endregion

        #region Metodos

        public DniInvalidoException()
            :base()
        { 
        
        }
        public DniInvalidoException(Exception e)
            : this()
        { 
        
        }

        public DniInvalidoException(String mensaje)
            : base(mensaje)
        {

        }

        public DniInvalidoException(String mensaje, Exception e)
            : base(mensaje, e)
        { 
        
        }
        #endregion
    }
}
