﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClasesAbstractas
{

    [Serializable]
    public abstract class Universitario:Persona
    {
        #region Fields
        private int legajo;
        #endregion

        #region Metodos
         #region Constructores

        public Universitario()
            :base()
        { 
        
        }
        public Universitario(int legajo, string nombre, string apellido, string dni, ENacionalidad nacionalidad)
            :base(nombre,apellido,dni,nacionalidad)
        {
            this.legajo = legajo;
        }


         #endregion

        #region Otros Metodos

        public override bool Equals(object obj)
        {
            //Check for null and compare run-time types.
            if ((obj == null) || !(this.GetType().Equals(obj.GetType())))
            {
                return false;
            }
            return true;
        }

        protected virtual string MostrarDatos()
        {
            return base.ToString() +"Legajo: "+this.legajo;
        
        }

        public static bool operator ==(Universitario pg1, Universitario pg2)
        {
            if (pg1.Equals(pg2))
            {
                if (pg1.DNI==pg2.DNI || pg1.legajo==pg2.legajo)
                {
                    return true;
                }   
            }
            return false;
        }
        public static bool operator !=(Universitario pg1, Universitario pg2)
        {
            return !(pg1 == pg2);

        }

        protected abstract string ParticiparEnClase();
        #endregion
        
        #endregion
    }
}
