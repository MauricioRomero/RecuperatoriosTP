﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excepciones;
namespace ClasesAbstractas
{
    [Serializable]
    public abstract class Persona
    {

        public enum ENacionalidad
        { 
            Argentino, Extranjero
        }

        #region Fields
        private string apellido;
        private int dni;
        private string nombre;
        private ENacionalidad nacionalidad;

        #endregion

        #region Properties

        public string Apellido { get { return this.apellido; } set { this.apellido = this.ValidarNombreApellido(value); } }
        public int DNI { get { return this.dni; } set { this.dni = this.ValidarDNI(this.nacionalidad,value); } }
        public ENacionalidad Nacionalidad { get { return this.nacionalidad; } set { this.nacionalidad = value; } }
        public String Nombre { get { return this.nombre; } set { this.nombre =this.ValidarNombreApellido( value); } }
        public String StringToDNI 
        { 
            set
            {
                int s;
                int.TryParse(value,out s);
                this.DNI=s;
            }
        }
        
        #endregion

        #region Metodos

         #region Constructores
        public Persona()
        { 
            
        }

        public Persona(string nombre, string apellido,ENacionalidad nacionalidad)
            :this()
        {
            this.Nombre = nombre;
            this.Apellido = apellido;
            this.nacionalidad = nacionalidad;
        }


        public Persona(string nombre, string apellido,int dni, ENacionalidad nacionalidad)
            :this(nombre,apellido,nacionalidad)
        {
            this.DNI = dni;
        }

        public Persona(string nombre, string apellido, string dni, ENacionalidad nacionalidad)
            :this(nombre,apellido,nacionalidad)
        
        {
            this.StringToDNI = dni;
        }



         #endregion

         #region OtrosMetodos
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("NOMBRE COMPLETO: {0},{1}",this.Apellido,this.Nombre);
            sb.AppendLine("\nNacionalidad: "+this.nacionalidad);
            return sb.ToString();
        }

        public int ValidarDNI(ENacionalidad nacionalidad, int dato)
        {
            int retD = 0;
            
                switch (nacionalidad)
                {
                    case ENacionalidad.Argentino:
                        if (dato < 89999999 && 1 < dato)
                        {
                            retD= dato;
                        }
                        else
                            throw new NacionalidadInvalidaException("La nacionalidad no coincide con su DNI");
                        break;
                    case ENacionalidad.Extranjero:
                        if (dato<999999999 && 90000000<dato)
                        {
                            retD = dato;
                        }
                        else
                            throw new NacionalidadInvalidaException("La nacionalidad no coincide con su DNI");
                        break;
                    default:
                        break;
                }
                return retD;
            
        
        }

        public string ValidarDNI(ENacionalidad nacionalidad, string dato)
        {
            
                //Valido Tamaño
            if (dato.Length > 9)
            {
                throw new DniInvalidoException("Tamaño DNI Invalido.");
            }
            else
            {
                int s;
                // Valido que todas las partes sean numéricas
                if (int.TryParse(dato, out s))
                {
                    //Valida valores numericos validos 
                    this.ValidarDNI(nacionalidad, s);
                }
                else
                    throw new DniInvalidoException("Formato DNI Invalido.");
            }

                return dato;
                
            
        }

        public string ValidarNombreApellido(string dato)
        {
            for (int i = 0; i < dato.Length; i++)
            {
                if (!(Char.IsLetter(dato[i])))
                {
                    return "-";
                }
            }
            return dato;
        
        }
         #endregion
        #endregion

    }
}
