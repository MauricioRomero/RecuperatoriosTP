﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Excepciones;
namespace Archivos
{
    public  class Texto
    {
        #region MEtodos
        public bool Guardar(string archivo,string datos)
        {
            bool resp = false;
            try
            {
                StreamWriter escritor = new StreamWriter(archivo+"/Universidad.txt",true);
                escritor.WriteLine(datos);
                escritor.Close();
                return true;
            }
            catch (Excepciones.ArchivosException ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadKey();
            }
            return resp;


        }
        public bool Leer(string archivo,out string datos)
        {
            bool resp = false;
            try
            {
                StreamReader reader = new StreamReader(archivo);
                datos = reader.ReadToEnd();
                reader.Close();
                resp = true;
            }
            catch (Excepciones.ArchivosException ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
            return resp;
        }
        #endregion
    }
}
