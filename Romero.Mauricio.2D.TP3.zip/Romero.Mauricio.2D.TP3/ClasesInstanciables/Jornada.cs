﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClasesAbstractas;
using Archivos;
namespace ClasesInstanciables
{
    [Serializable]
    public class Jornada
    {
        #region Fields

        private List<Alumno> alumnos;
        private EClase clase;
        private Profesor instructor;




        #endregion

        #region Propiedades

        public List<Alumno> Alumnos { get { return this.alumnos; } set { this.alumnos = value; } }
        public EClase Clase { get { return this.clase; } set { this.Clase = value; } }
        public Profesor Instructor { get { return this.instructor; } set { this.instructor = value; } }
        
        #endregion



        #region Metodos

         #region Constructores
        private Jornada()
        {
            this.alumnos = new List<Alumno>();
        }

        public Jornada(EClase clase, Profesor instructor)
            :this()
        {
            this.clase = clase;
            this.instructor = instructor;

        }
         #endregion
        
         #region Operadores
        public static bool operator ==(Jornada j, Alumno a)
        {
            if (!(Object.Equals(a, null)))
            {
                if (!(a!=j.clase))
                {
                    return true;
                }
            }
            
            return false;
        }
        public static bool operator !=(Jornada j, Alumno a)
        {
            return !(j==a);
        }
        public static bool operator +(Jornada j, Alumno a)
        {
            if (j!=a)
            {
                j.alumnos.Add(a);
                return true;
            }
            return false;
        }
         #endregion

         #region OtrosMetodos

        public static bool Guardar(Jornada j)
        {
            Texto t = new Texto();
            string archivo=Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            
            return t.Guardar(archivo, j.ToString());
            
        }

        public static string Leer()
        {
            
            Texto t = new Texto();
            string archivo = Environment.SpecialFolder.Desktop + @"/Jornada.txt";
            string datos;
            t.Leer(archivo,out datos);
            return datos;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("JORNADA: ");
            sb.AppendFormat("CLASE DE {0} POR {1}",this.Clase,this.Instructor.ToString());
            sb.AppendLine("\nALUMNOS:");
            foreach (Alumno item in this.Alumnos)
            {
                sb.AppendLine(item.ToString());
            }
            sb.AppendLine("<--------------------------------------------------------->");
            return sb.ToString();
        }
         #endregion
        #endregion






    }
}
