﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excepciones;
using Archivos;
namespace ClasesInstanciables
{

    [Serializable]
   public class Universidad
    {
        #region Fields

        private List<Alumno> alumnos;
        private List<Jornada> jornada;
        private List<Profesor> profesor;
        #endregion

        #region Propiedades

        public List<Alumno> Alumnos { get { return this.alumnos; } set { this.alumnos = value; } }
        public List<Jornada> Jornadas { get { return this.jornada; } set { this.jornada = value; } }
        public List<Profesor> Profesores { get {return this.profesor; } set { this.profesor = value; } }
        public Jornada this[int i] 
        {
            get
            { 
                return this.jornada[i];
            }
            set
            {
                this.jornada[i] = value;
            }
        
        }

        #endregion
        
        #region Metodos

        public Universidad()
        {
            this.alumnos = new List<Alumno>();
            this.profesor = new List<Profesor>();
            this.jornada=new List<Jornada> ();
        }
         #region Operadores

          #region Operadores de Igualdad
        /// <summary>
        /// Un Universidad será igual a un Alumno si el mismo está inscripto en él
        /// </summary>
        /// <param name="u">Universidad</param>
        /// <param name="a">Alumno</param>
        /// <returns>bool</returns>
        public static bool operator ==(Universidad u, Alumno a)
        {
            foreach (Alumno item in u.Alumnos)
            {
                if (item==a)
                {
                    return true;
                }
            }
            return false;
        }
        public static bool operator !=(Universidad u, Alumno a)
        {
            return !(u==a);
        }

        /// <summary>
        /// La igualación entre un Universidad y una Clase retornará el primer Profesor capaz de dar esa clase.
        /// Sino, lanzará la Excepción SinProfesorException.
        /// El distinto retornará el primer Profesor que no pueda dar la clase. 
        /// </summary>
        /// <param name="u">Universidad</param>
        /// <param name="clase">EClase</param>
        /// <returns>Profesor</returns>
        public static Profesor operator ==(Universidad u, EClase clase)
        {
            foreach (Profesor item in u.profesor)
            {
                if (item==clase)
                {
                    return item;
                }       
            }
            throw new SinProfesorException();/// SinProfesorException;
        }
        public static Profesor operator !=(Universidad u, EClase clase)
        {
            foreach (Profesor item in u.profesor)
            {
                if (item!=clase)
                {
                    return item;
                }
            }
            throw new SinProfesorException();//Sin profesor Exception
        }

        /// <summary>
        /// Un Universidad será igual a un Profesor si el mismo está dando clases en él
        /// </summary>
        /// <param name="u">Universidad</param>
        /// <param name="i">Profesor</param>
        /// <returns>bool</returns>
        public static bool operator ==(Universidad u, Profesor i)
        {
            if (!(Object.Equals(i,null)))
            {
                foreach (Profesor item in u.profesor)
                {
                    if (item == i)
                    {
                        return true;
                    }
                }    
            }

            
            return false;
        }
        public static bool operator !=(Universidad u, Profesor i)
        {
            return !(u==i);
        }
          #endregion


          #region Operadores +
        
        /// <summary>
        /// Se agregarán Alumnos, validando que no estén previamente cargados
        /// </summary>
        /// <param name="u">Universidad</param>
        /// <param name="a">Alumno</param>
        /// <returns>Universidad</returns>
        public static Universidad operator +(Universidad u,Alumno a)
        {
            if (u == a)
            {
               // Console.WriteLine("Alumno Repetido.");
                throw new AlumnoRepetidoException();
                
            }
            else
                u.Alumnos.Add(a);

            return u;
        }

        /// <summary>
        /// Se agregará Profesor, validando que no estén previamente cargados
        /// </summary>
        /// <param name="u"></param>
        /// <param name="i"></param>
        /// <returns>Universidad</returns>
        public static Universidad operator +(Universidad u,Profesor i)
        {
            if (u == i)
            {
                Console.WriteLine("Profesor Repetido.");
            }
            else
                u.Profesores.Add(i);
            return u;
        }

        /// <summary>
        /// Al agregar una clase a un Universidad se deberá generar y agregar una nueva Jornada indicando la clase,
        /// un Profesor que pueda darla (según su atributo ClasesDelDia)
        /// y la lista de alumnos que la toman (todos los que coincidan en su campo ClaseQueToma).
        /// </summary>
        /// <param name="u">Univeridad</param>
        /// <param name="clase">EClase</param>
        /// <returns>Universidad</returns>
        
        public static Universidad operator +(Universidad u,EClase clase)
        {
            //Profesor p = new Profesor();
            //p = (u == clase);
            foreach (Profesor item in u.profesor)
            {
                if (item==clase)
                {
                    Jornada j=new Jornada(clase, item);
                    
                    foreach (Alumno itemA in u.Alumnos)
                    {
                        if (itemA == clase)
                        {
                            j.Alumnos.Add(itemA);
                        }
                    }
                    u.Jornadas.Add(j);
                    break;
                }
            }
            
                    
            
            
            return u;
        }

          #endregion

        #endregion

        #region OtrosMetodos
        public static bool Guardar(Universidad u)
        {
            XmlT<Universidad> xmlU = new XmlT<Universidad>();
            XmlT<Jornada> xmlJ = new XmlT<Jornada>();
            XmlT<Profesor> xmlP = new XmlT<Profesor>();
            XmlT<Alumno> xmlA = new XmlT<Alumno>();

            string archivo=Environment.GetFolderPath(Environment.SpecialFolder.Desktop)+"/Universidad.xml";
            //foreach (Jornada item in u.jornada)
            //{
            //    xmlJ.Guardar(archivo, item);
            //}
            xmlU.Guardar(archivo, u);
            
            return true;
        }

        private string MostrarDatos()
        {
            StringBuilder sb = new StringBuilder();
            foreach (Jornada item in this.Jornadas)
            {
                sb.AppendLine(item.ToString());
            }
            return sb.ToString();
        }

        public override string ToString()
        {
            return this.MostrarDatos();
        }
         #endregion
        #endregion

    }
    public enum EClase
    { 
        Programacion,
        Laboratorio,
        Legislacion,
        SPD
    }
}
