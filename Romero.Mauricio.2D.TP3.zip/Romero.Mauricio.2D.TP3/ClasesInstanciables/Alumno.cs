﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClasesAbstractas;
namespace ClasesInstanciables
{

    [Serializable]
    public sealed class Alumno:Universitario
    {
        #region Fields
        private EClase claseQueToma;
        private EEstadoDeCuenta estadoDeCuenta;

        #endregion


        #region Metodos

        #region Constructores

        public Alumno()
            :base()
        { }

        public Alumno(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad, EClase claseQueToma)
            : base(id, nombre, apellido, dni, nacionalidad)
        {
            this.claseQueToma = claseQueToma;

        }
        public Alumno(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad, EClase claseQueToma, EEstadoDeCuenta estadoDeCuenta)
            : this(id, nombre, apellido, dni, nacionalidad,claseQueToma)
        {
            this.estadoDeCuenta = estadoDeCuenta;
        }
        #endregion

         #region OtrosMetodos

        protected override string MostrarDatos()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.MostrarDatos());
            sb.AppendLine("Clase que Toma: "+this.claseQueToma);
            sb.AppendLine("Estado de cuenta: " + this.estadoDeCuenta);
            return sb.ToString();
        }

        public static bool operator ==(Alumno a1, EClase clase)
        {

            if (!object.Equals(a1,null))
            {
                if (a1.claseQueToma==clase && a1.estadoDeCuenta!=EEstadoDeCuenta.Deudor)
                {
                    return true;
                }
            }

            return false;
        }
        public static bool operator !=(Alumno a1, EClase clase)
        {

            if (!object.Equals(a1, null))
            {
                if (!(a1.claseQueToma == clase))
                {
                    return true;
                }
            }
            return false;
        }
        protected override string ParticiparEnClase()
        {
            return "TOMA CLASE DE " + this.claseQueToma;
        }

        public override string ToString()
        {
            return this.MostrarDatos();
        }

         #endregion

        #endregion
    }
    public enum EEstadoDeCuenta
    {
        AlDia,
        Deudor,
        Becado
    }
}
