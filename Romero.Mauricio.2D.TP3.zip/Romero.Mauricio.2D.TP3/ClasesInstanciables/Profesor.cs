﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using ClasesAbstractas;
namespace ClasesInstanciables
{

    [Serializable]
    public sealed class Profesor:Universitario
    {
        #region Fields
        private Queue<EClase> clasesDelDia;
        private static Random random;
        #endregion

        #region MEtodos

         #region Constructores

        static Profesor()
        {
            Profesor.random = new Random();
        }
        public Profesor()
            :base()
        {
            this.clasesDelDia = new Queue<EClase>();
            this._randomClases();
        }
        public Profesor(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad)
            : base(id, nombre, apellido, dni, nacionalidad)
        {
            this.clasesDelDia = new Queue<EClase>();
            this._randomClases();
        }

        #endregion


        #region OtrosMetods

        private void _randomClases()
        {
            int m;
            for (int i = 0; i < 2; i++)
            {
                m=Profesor.random.Next(1, 4);
                this.clasesDelDia.Enqueue((EClase)m);
                
            }
        
        }

        protected string MostrarDatos()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.MostrarDatos());
            sb.AppendLine("\nCLASES DEL DIA: ");
            foreach (EClase item in this.clasesDelDia)
            {
                sb.AppendLine(item.ToString());
            }
            //sb.AppendLine("Random: "+Profesor.random);
            return sb.ToString();
        }

        public override string ToString()
        {

            return this.MostrarDatos();
        }

        public static bool operator ==(Profesor i, EClase clase)
        {
            foreach (EClase item in i.clasesDelDia)
            {
                if (item==clase)
                {
                    return true;
                }
            }
            return false;
        }
        public static bool operator !=(Profesor i, EClase clase)
        {

            return !(i==clase);
        }

        protected override string ParticiparEnClase()
        {
            return "TOMA CLASE DE " + this.clasesDelDia.Peek();
        
        }
        #endregion

        #endregion


    }
}
